/*
 * File: New_SPRO4.c
 *
 * Code generated for Simulink model 'New_SPRO4'.
 *
 * Model version                  : 1.57
 * Simulink Coder version         : 26.1 (R2026a) 20-Nov-2025
 * C/C++ source code generated on : Mon May 25 10:09:21 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#include "New_SPRO4.h"
#include "rtwtypes.h"
#include <math.h>
#include "math.h"

/* Private macros used by the generated code to access rtModel */
#ifndef rtmIsMajorTimeStep
#define rtmIsMajorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
#define rtmIsMinorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmSetTPtr
#define rtmSetTPtr(rtm, val)           ((rtm)->Timing.t = (val))
#endif

/* Continuous states */
X rtX;

/* Disabled State Vector */
XDis rtXDis;

/* Block signals and states (default storage) */
DW rtDW;

/* Real-time model */
static RT_MODEL rtM_;
RT_MODEL *const rtM = &rtM_;
extern real_T rt_urand_Upu32_Yd_f_pw_snf(uint32_T *u);
extern real_T rt_nrand_Upu32_Yd_f_pw_snf(uint32_T *u);

/* private model entry point functions */
extern void New_SPRO4_derivatives(void);
static real_T rtGetNaN(void);
static real32_T rtGetNaNF(void);
extern real_T rtInf;
extern real_T rtMinusInf;
extern real_T rtNaN;
extern real32_T rtInfF;
extern real32_T rtMinusInfF;
extern real32_T rtNaNF;
static boolean_T rtIsInf(real_T value);
static boolean_T rtIsInfF(real32_T value);
static boolean_T rtIsNaN(real_T value);
static boolean_T rtIsNaNF(real32_T value);
real_T rtNaN = -(real_T)NAN;
real_T rtInf = (real_T)INFINITY;
real_T rtMinusInf = -(real_T)INFINITY;
real32_T rtNaNF = -(real32_T)NAN;
real32_T rtInfF = (real32_T)INFINITY;
real32_T rtMinusInfF = -(real32_T)INFINITY;

/* Return rtNaN needed by the generated code. */
static real_T rtGetNaN(void)
{
  return rtNaN;
}

/* Return rtNaNF needed by the generated code. */
static real32_T rtGetNaNF(void)
{
  return rtNaNF;
}

/* Test if value is infinite */
static boolean_T rtIsInf(real_T value)
{
  return (boolean_T)isinf(value);
}

/* Test if single-precision value is infinite */
static boolean_T rtIsInfF(real32_T value)
{
  return (boolean_T)isinf(value);
}

/* Test if value is not a number */
static boolean_T rtIsNaN(real_T value)
{
  return (boolean_T)(isnan(value) != 0);
}

/* Test if single-precision value is not a number */
static boolean_T rtIsNaNF(real32_T value)
{
  return (boolean_T)(isnan(value) != 0);
}

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 7;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  New_SPRO4_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  New_SPRO4_step();
  New_SPRO4_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  New_SPRO4_step();
  New_SPRO4_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

real_T rt_urand_Upu32_Yd_f_pw_snf(uint32_T *u)
{
  uint32_T hi;
  uint32_T lo;

  /* Uniform random number generator (random number between 0 and 1)

     #define IA      16807                      magic multiplier = 7^5
     #define IM      2147483647                 modulus = 2^31-1
     #define IQ      127773                     IM div IA
     #define IR      2836                       IM modulo IA
     #define S       4.656612875245797e-10      reciprocal of 2^31-1
     test = IA * (seed % IQ) - IR * (seed/IQ)
     seed = test < 0 ? (test + IM) : test
     return (seed*S)
   */
  lo = *u % 127773U * 16807U;
  hi = *u / 127773U * 2836U;
  if (lo < hi) {
    *u = 2147483647U - (hi - lo);
  } else {
    *u = lo - hi;
  }

  return (real_T)*u * 4.656612875245797E-10;
}

real_T rt_nrand_Upu32_Yd_f_pw_snf(uint32_T *u)
{
  real_T si;
  real_T sr;
  real_T y;

  /* Normal (Gaussian) random number generator */
  do {
    sr = 2.0 * rt_urand_Upu32_Yd_f_pw_snf(u) - 1.0;
    si = 2.0 * rt_urand_Upu32_Yd_f_pw_snf(u) - 1.0;
    si = sr * sr + si * si;
  } while (si > 1.0);

  y = sqrt(-2.0 * log(si) / si) * sr;
  return y;
}

/* Model step function */
void New_SPRO4_step(void)
{
  real_T rtb_IntegralGain;
  real_T rtb_LoadTorque;
  real_T rtb_SignPreSat;
  real_T tmp;
  real_T tmp_0;
  boolean_T rtb_IntegralGain_tmp;
  if (rtmIsMajorTimeStep(rtM)) {
    /* set solver stop time */
    rtsiSetSolverStopTime(&rtM->solverInfo,((rtM->Timing.clockTick0+1)*
      rtM->Timing.stepSize0));
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(rtM)) {
    rtM->Timing.t[0] = rtsiGetT(&rtM->solverInfo);
  }

  /* Integrator: '<S1>/Integrator1' */
  /* Limited  Integrator  */
  if (rtX.Integrator1_CSTATE >= 10.0) {
    rtX.Integrator1_CSTATE = 10.0;
  } else if (rtX.Integrator1_CSTATE <= 0.0) {
    rtX.Integrator1_CSTATE = 0.0;
  }

  /* Sum: '<S4>/Cable Stretch' incorporates:
   *  Integrator: '<S1>/Integrator1'
   *  Integrator: '<S5>/Second_Integrator_cable length'
   */
  rtb_SignPreSat = rtX.Integrator1_CSTATE - rtX.Second_Integrator_cablelength_C;

  /* Gain: '<S5>/Drum Radius' incorporates:
   *  Integrator: '<S5>/Integrator'
   */
  rtDW.CableVelocity = 0.015 * rtX.Integrator_CSTATE;

  /* Integrator: '<S1>/Integrator' */
  /* Limited  Integrator  */
  if (rtX.Integrator_CSTATE_a >= 2.0) {
    rtX.Integrator_CSTATE_a = 2.0;
  } else if (rtX.Integrator_CSTATE_a <= -2.0) {
    rtX.Integrator_CSTATE_a = -2.0;
  }

  /* Integrator: '<S1>/Integrator' */
  rtDW.DroneVelocity = rtX.Integrator_CSTATE_a;

  /* Saturate: '<S4>/No negative tension' */
  if (rtb_SignPreSat <= 0.0) {
    rtb_SignPreSat = 0.0;
  }

  /* Sum: '<S4>/Total Tension' incorporates:
   *  Gain: '<S4>/Damping Gain'
   *  Gain: '<S4>/k (stiffness)'
   *  Saturate: '<S4>/No negative tension'
   *  Sum: '<S4>/Relative velocity'
   */
  rtb_IntegralGain = (rtDW.CableVelocity - rtDW.DroneVelocity) * 1.286 + 2.0 *
    rtb_SignPreSat;

  /* Saturate: '<S4>/No negative tension1' */
  if (rtb_IntegralGain <= 0.0) {
    rtb_IntegralGain = 0.0;
  }

  /* End of Saturate: '<S4>/No negative tension1' */

  /* Saturate: '<S1>/Saturation' incorporates:
   *  Constant: '<S1>/Gravitational Force'
   *  Constant: '<S1>/Thrust constant'
   *  Sum: '<S1>/Sum'
   */
  if ((0.55 - rtb_IntegralGain) - 0.486576 < -5.0) {
    tmp = -5.0;
  } else {
    tmp = (0.55 - rtb_IntegralGain) - 0.486576;
  }

  /* Gain: '<S1>/Gain' incorporates:
   *  Saturate: '<S1>/Saturation'
   */
  rtDW.Acceleration = 20.16 * tmp;
  rtb_IntegralGain_tmp = (rtmIsMajorTimeStep(rtM) &&
    rtM->Timing.TaskCounters.TID[1] == 0);
  if (rtb_IntegralGain_tmp) {
    /* Gain: '<S6>/Output' incorporates:
     *  RandomNumber: '<S6>/White Noise'
     */
    rtDW.Output = 0.002077979788159644 * rtDW.NextOutput;
  }

  /* Sum: '<S2>/Sum' */
  rtDW.Sum = rtb_IntegralGain + rtDW.Output;

  /* Gain: '<S5>/DrumRadius' */
  rtb_LoadTorque = 0.015 * rtb_IntegralGain;

  /* TransferFcn: '<S2>/Lowpass_smooth' */
  rtb_IntegralGain = 10.0 * rtX.Lowpass_smooth_CSTATE;

  /* Integrator: '<S43>/Integrator' */
  /* Limited  Integrator  */
  if (rtX.Integrator_CSTATE_k >= 0.0078) {
    rtX.Integrator_CSTATE_k = 0.0078;
  } else if (rtX.Integrator_CSTATE_k <= -0.0078) {
    rtX.Integrator_CSTATE_k = -0.0078;
  }

  /* Gain: '<S46>/Filter Coefficient' incorporates:
   *  Constant: '<Root>/Tension Ref'
   *  Gain: '<S36>/Derivative Gain'
   *  Integrator: '<S38>/Filter'
   *  Sum: '<Root>/e(t)=T_ref-T_measured'
   *  Sum: '<S38>/SumD'
   */
  rtDW.FilterCoefficient = ((4.25 - rtb_IntegralGain) * 0.001 -
    rtX.Filter_CSTATE) * 10.0;

  /* Sum: '<S52>/Sum' incorporates:
   *  Constant: '<Root>/Tension Ref'
   *  Gain: '<S48>/Proportional Gain'
   *  Integrator: '<S43>/Integrator'
   *  Sum: '<Root>/e(t)=T_ref-T_measured'
   */
  rtb_SignPreSat = ((4.25 - rtb_IntegralGain) * 0.005 + rtX.Integrator_CSTATE_k)
    + rtDW.FilterCoefficient;

  /* Saturate: '<S50>/Saturation' */
  if (rtb_SignPreSat > 0.0084) {
    tmp = 0.0084;
  } else if (rtb_SignPreSat < -0.0084) {
    tmp = -0.0084;
  } else {
    tmp = rtb_SignPreSat;
  }

  /* Gain: '<S5>/Gain_1//J' incorporates:
   *  Gain: '<Root>/Gain'
   *  Saturate: '<S50>/Saturation'
   *  Sum: '<S5>/Sum'
   */
  rtDW.AngularAcceleration = (-tmp - rtb_LoadTorque) * 100.0;

  /* Gain: '<S33>/ZeroGain' */
  rtb_LoadTorque = 0.0 * rtb_SignPreSat;

  /* DeadZone: '<S35>/DeadZone' */
  if (rtb_SignPreSat > 0.0084) {
    rtb_SignPreSat -= 0.0084;
  } else if (rtb_SignPreSat >= -0.0084) {
    rtb_SignPreSat = 0.0;
  } else {
    rtb_SignPreSat -= -0.0084;
  }

  /* End of DeadZone: '<S35>/DeadZone' */

  /* Gain: '<S40>/Integral Gain' incorporates:
   *  Constant: '<Root>/Tension Ref'
   *  Sum: '<Root>/e(t)=T_ref-T_measured'
   */
  rtb_IntegralGain = (4.25 - rtb_IntegralGain) * 0.002;

  /* Signum: '<S33>/SignPreSat' */
  if (rtIsNaN(rtb_SignPreSat)) {
    tmp = (rtNaN);
  } else if (rtb_SignPreSat < 0.0) {
    tmp = -1.0;
  } else {
    tmp = (rtb_SignPreSat > 0.0);
  }

  /* Signum: '<S33>/SignPreIntegrator' */
  if (rtIsNaN(rtb_IntegralGain)) {
    tmp_0 = (rtNaN);
  } else if (rtb_IntegralGain < 0.0) {
    tmp_0 = -1.0;
  } else {
    tmp_0 = (rtb_IntegralGain > 0.0);
  }

  /* Logic: '<S33>/AND3' incorporates:
   *  DataTypeConversion: '<S33>/DataTypeConv1'
   *  DataTypeConversion: '<S33>/DataTypeConv2'
   *  RelationalOperator: '<S33>/Equal1'
   *  RelationalOperator: '<S33>/NotEqual'
   *  Signum: '<S33>/SignPreIntegrator'
   *  Signum: '<S33>/SignPreSat'
   */
  rtDW.AND3 = ((rtb_LoadTorque != rtb_SignPreSat) && ((int8_T)tmp == (int8_T)
    tmp_0));
  if (rtb_IntegralGain_tmp) {
    /* Memory: '<S33>/Memory' */
    rtDW.Memory = rtDW.Memory_PreviousInput;
  }

  /* Switch: '<S33>/Switch' */
  if (rtDW.Memory) {
    /* Switch: '<S33>/Switch' incorporates:
     *  Constant: '<S33>/Constant1'
     */
    rtDW.Switch = 0.0;
  } else {
    /* Switch: '<S33>/Switch' */
    rtDW.Switch = rtb_IntegralGain;
  }

  /* End of Switch: '<S33>/Switch' */
  if (rtmIsMajorTimeStep(rtM)) {
    if (rtmIsMajorTimeStep(rtM) &&
        rtM->Timing.TaskCounters.TID[1] == 0) {
      /* Update for RandomNumber: '<S6>/White Noise' */
      rtDW.NextOutput = rt_nrand_Upu32_Yd_f_pw_snf(&rtDW.RandSeed);

      /* Update for Memory: '<S33>/Memory' */
      rtDW.Memory_PreviousInput = rtDW.AND3;
    }
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(rtM)) {
    rt_ertODEUpdateContinuousStates(&rtM->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     */
    ++rtM->Timing.clockTick0;
    rtM->Timing.t[0] = rtsiGetSolverStopTime(&rtM->solverInfo);

    {
      /* Update absolute timer for sample time: [0.1s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.1, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       */
      rtM->Timing.clockTick1++;
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void New_SPRO4_derivatives(void)
{
  XDot *_rtXdot;
  boolean_T lsat;
  boolean_T usat;
  _rtXdot = ((XDot *) rtM->derivs);

  /* Derivatives for Integrator: '<S5>/Second_Integrator_cable length' */
  _rtXdot->Second_Integrator_cablelength_C = rtDW.CableVelocity;

  /* Derivatives for Integrator: '<S1>/Integrator1' */
  lsat = (rtX.Integrator1_CSTATE <= 0.0);
  usat = (rtX.Integrator1_CSTATE >= 10.0);
  if ((!lsat && !usat) || (lsat && (rtDW.DroneVelocity > 0.0)) || (usat &&
       (rtDW.DroneVelocity < 0.0))) {
    _rtXdot->Integrator1_CSTATE = rtDW.DroneVelocity;
  } else {
    /* in saturation */
    _rtXdot->Integrator1_CSTATE = 0.0;
  }

  /* End of Derivatives for Integrator: '<S1>/Integrator1' */

  /* Derivatives for Integrator: '<S5>/Integrator' */
  _rtXdot->Integrator_CSTATE = rtDW.AngularAcceleration;

  /* Derivatives for Integrator: '<S1>/Integrator' */
  lsat = (rtX.Integrator_CSTATE_a <= -2.0);
  usat = (rtX.Integrator_CSTATE_a >= 2.0);
  if ((!lsat && !usat) || (lsat && (rtDW.Acceleration > 0.0)) || (usat &&
       (rtDW.Acceleration < 0.0))) {
    _rtXdot->Integrator_CSTATE_a = rtDW.Acceleration;
  } else {
    /* in saturation */
    _rtXdot->Integrator_CSTATE_a = 0.0;
  }

  /* End of Derivatives for Integrator: '<S1>/Integrator' */

  /* Derivatives for TransferFcn: '<S2>/Lowpass_smooth' */
  _rtXdot->Lowpass_smooth_CSTATE = -10.0 * rtX.Lowpass_smooth_CSTATE;
  _rtXdot->Lowpass_smooth_CSTATE += rtDW.Sum;

  /* Derivatives for Integrator: '<S43>/Integrator' */
  lsat = (rtX.Integrator_CSTATE_k <= -0.0078);
  usat = (rtX.Integrator_CSTATE_k >= 0.0078);
  if ((!lsat && !usat) || (lsat && (rtDW.Switch > 0.0)) || (usat && (rtDW.Switch
        < 0.0))) {
    _rtXdot->Integrator_CSTATE_k = rtDW.Switch;
  } else {
    /* in saturation */
    _rtXdot->Integrator_CSTATE_k = 0.0;
  }

  /* End of Derivatives for Integrator: '<S43>/Integrator' */

  /* Derivatives for Integrator: '<S38>/Filter' */
  _rtXdot->Filter_CSTATE = rtDW.FilterCoefficient;
}

/* Model initialize function */
void New_SPRO4_initialize(void)
{
  /* Registration code */
  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&rtM->solverInfo, &rtM->Timing.simTimeStep);
    rtsiSetTPtr(&rtM->solverInfo, &rtmGetTPtr(rtM));
    rtsiSetStepSizePtr(&rtM->solverInfo, &rtM->Timing.stepSize0);
    rtsiSetdXPtr(&rtM->solverInfo, &rtM->derivs);
    rtsiSetContStatesPtr(&rtM->solverInfo, (real_T **) &rtM->contStates);
    rtsiSetNumContStatesPtr(&rtM->solverInfo, &rtM->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&rtM->solverInfo,
      &rtM->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&rtM->solverInfo,
      &rtM->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&rtM->solverInfo,
      &rtM->periodicContStateRanges);
    rtsiSetContStateDisabledPtr(&rtM->solverInfo, (boolean_T**)
      &rtM->contStateDisabled);
    rtsiSetErrorStatusPtr(&rtM->solverInfo, (&rtmGetErrorStatus(rtM)));
    rtsiSetRTModelPtr(&rtM->solverInfo, rtM);
  }

  rtsiSetSimTimeStep(&rtM->solverInfo, MAJOR_TIME_STEP);
  rtsiSetIsMinorTimeStepWithModeChange(&rtM->solverInfo, false);
  rtsiSetIsContModeFrozen(&rtM->solverInfo, false);
  rtM->intgData.y = rtM->odeY;
  rtM->intgData.f[0] = rtM->odeF[0];
  rtM->intgData.f[1] = rtM->odeF[1];
  rtM->intgData.f[2] = rtM->odeF[2];
  rtM->contStates = ((X *) &rtX);
  rtM->contStateDisabled = ((XDis *) &rtXDis);
  rtM->Timing.tStart = (0.0);
  rtsiSetSolverData(&rtM->solverInfo, (void *)&rtM->intgData);
  rtsiSetSolverName(&rtM->solverInfo,"ode3");
  rtmSetTPtr(rtM, &rtM->Timing.tArray[0]);
  rtM->Timing.stepSize0 = 0.1;

  /* InitializeConditions for Integrator: '<S5>/Second_Integrator_cable length' */
  rtX.Second_Integrator_cablelength_C = 1.8;

  /* InitializeConditions for Integrator: '<S1>/Integrator1' */
  rtX.Integrator1_CSTATE = 1.8;

  /* InitializeConditions for Integrator: '<S5>/Integrator' */
  rtX.Integrator_CSTATE = 0.0;

  /* InitializeConditions for Integrator: '<S1>/Integrator' */
  rtX.Integrator_CSTATE_a = 0.0;

  /* InitializeConditions for RandomNumber: '<S6>/White Noise' */
  rtDW.RandSeed = 1529675776U;
  rtDW.NextOutput = rt_nrand_Upu32_Yd_f_pw_snf(&rtDW.RandSeed);

  /* InitializeConditions for TransferFcn: '<S2>/Lowpass_smooth' */
  rtX.Lowpass_smooth_CSTATE = 0.0;

  /* InitializeConditions for Integrator: '<S43>/Integrator' */
  rtX.Integrator_CSTATE_k = 0.0;

  /* InitializeConditions for Integrator: '<S38>/Filter' */
  rtX.Filter_CSTATE = 0.0;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
