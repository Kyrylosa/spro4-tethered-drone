/*
 * File: New_SPRO4.h
 *
 * Code generated for Simulink model 'New_SPRO4'.
 *
 * Model version                  : 1.57
 * Simulink Coder version         : 26.1 (R2026a) 20-Nov-2025
 * C/C++ source code generated on : Mon May 25 10:09:21 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#ifndef New_SPRO4_h_
#define New_SPRO4_h_
#ifndef New_SPRO4_COMMON_INCLUDES_
#define New_SPRO4_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "math.h"
#endif                                 /* New_SPRO4_COMMON_INCLUDES_ */

#include <string.h>

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#ifndef rtmGetTStart
#define rtmGetTStart(rtm)              ((rtm)->Timing.tStart)
#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM RT_MODEL;

/* Block signals and states (default storage) for system '<Root>' */
typedef struct {
  real_T CableVelocity;                /* '<S5>/Drum Radius' */
  real_T DroneVelocity;                /* '<S1>/Integrator' */
  real_T Acceleration;                 /* '<S1>/Gain' */
  real_T Output;                       /* '<S6>/Output' */
  real_T Sum;                          /* '<S2>/Sum' */
  real_T FilterCoefficient;            /* '<S46>/Filter Coefficient' */
  real_T AngularAcceleration;          /* '<S5>/Gain_1//J' */
  real_T Switch;                       /* '<S33>/Switch' */
  real_T NextOutput;                   /* '<S6>/White Noise' */
  uint32_T RandSeed;                   /* '<S6>/White Noise' */
  boolean_T AND3;                      /* '<S33>/AND3' */
  boolean_T Memory;                    /* '<S33>/Memory' */
  boolean_T Memory_PreviousInput;      /* '<S33>/Memory' */
} DW;

/* Continuous states (default storage) */
typedef struct {
  real_T Second_Integrator_cablelength_C;
                                     /* '<S5>/Second_Integrator_cable length' */
  real_T Integrator1_CSTATE;           /* '<S1>/Integrator1' */
  real_T Integrator_CSTATE;            /* '<S5>/Integrator' */
  real_T Integrator_CSTATE_a;          /* '<S1>/Integrator' */
  real_T Lowpass_smooth_CSTATE;        /* '<S2>/Lowpass_smooth' */
  real_T Integrator_CSTATE_k;          /* '<S43>/Integrator' */
  real_T Filter_CSTATE;                /* '<S38>/Filter' */
} X;

/* State derivatives (default storage) */
typedef struct {
  real_T Second_Integrator_cablelength_C;
                                     /* '<S5>/Second_Integrator_cable length' */
  real_T Integrator1_CSTATE;           /* '<S1>/Integrator1' */
  real_T Integrator_CSTATE;            /* '<S5>/Integrator' */
  real_T Integrator_CSTATE_a;          /* '<S1>/Integrator' */
  real_T Lowpass_smooth_CSTATE;        /* '<S2>/Lowpass_smooth' */
  real_T Integrator_CSTATE_k;          /* '<S43>/Integrator' */
  real_T Filter_CSTATE;                /* '<S38>/Filter' */
} XDot;

/* State disabled  */
typedef struct {
  boolean_T Second_Integrator_cablelength_C;
                                     /* '<S5>/Second_Integrator_cable length' */
  boolean_T Integrator1_CSTATE;        /* '<S1>/Integrator1' */
  boolean_T Integrator_CSTATE;         /* '<S5>/Integrator' */
  boolean_T Integrator_CSTATE_a;       /* '<S1>/Integrator' */
  boolean_T Lowpass_smooth_CSTATE;     /* '<S2>/Lowpass_smooth' */
  boolean_T Integrator_CSTATE_k;       /* '<S43>/Integrator' */
  boolean_T Filter_CSTATE;             /* '<S38>/Filter' */
} XDis;

#ifndef ODE3_INTG
#define ODE3_INTG

/* ODE3 Integration Data */
typedef struct {
  real_T *y;                           /* output */
  real_T *f[3];                        /* derivatives */
} ODE3_IntgData;

#endif

/* Real-time Model Data Structure */
struct tag_RTM {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;
  X *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  XDis *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[7];
  real_T odeF[3][7];
  ODE3_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    struct {
      uint8_T TID[2];
    } TaskCounters;

    time_T tStart;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Continuous states (default storage) */
extern X rtX;

/* Disabled states (default storage) */
extern XDis rtXDis;

/* Block signals and states (default storage) */
extern DW rtDW;

/* Model entry point functions */
extern void New_SPRO4_initialize(void);
extern void New_SPRO4_step(void);

/* Real-time Model object */
extern RT_MODEL *const rtM;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<Root>/Cable Length' : Unused code path elimination
 * Block '<Root>/Drone Height' : Unused code path elimination
 * Block '<Root>/Drone Velocity' : Unused code path elimination
 * Block '<Root>/Measured Tension' : Unused code path elimination
 * Block '<Root>/Torque' : Unused code path elimination
 * Block '<Root>/Torque Limiter' : Unused code path elimination
 * Block '<Root>/True Tension' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'New_SPRO4'
 * '<S1>'   : 'New_SPRO4/Drone'
 * '<S2>'   : 'New_SPRO4/Sensor'
 * '<S3>'   : 'New_SPRO4/Tension PID'
 * '<S4>'   : 'New_SPRO4/Tether'
 * '<S5>'   : 'New_SPRO4/WInch'
 * '<S6>'   : 'New_SPRO4/Sensor/Noise_error'
 * '<S7>'   : 'New_SPRO4/Tension PID/Anti-windup'
 * '<S8>'   : 'New_SPRO4/Tension PID/D Gain'
 * '<S9>'   : 'New_SPRO4/Tension PID/External Derivative'
 * '<S10>'  : 'New_SPRO4/Tension PID/Filter'
 * '<S11>'  : 'New_SPRO4/Tension PID/Filter ICs'
 * '<S12>'  : 'New_SPRO4/Tension PID/I Gain'
 * '<S13>'  : 'New_SPRO4/Tension PID/Ideal P Gain'
 * '<S14>'  : 'New_SPRO4/Tension PID/Ideal P Gain Fdbk'
 * '<S15>'  : 'New_SPRO4/Tension PID/Integrator'
 * '<S16>'  : 'New_SPRO4/Tension PID/Integrator ICs'
 * '<S17>'  : 'New_SPRO4/Tension PID/N Copy'
 * '<S18>'  : 'New_SPRO4/Tension PID/N Gain'
 * '<S19>'  : 'New_SPRO4/Tension PID/P Copy'
 * '<S20>'  : 'New_SPRO4/Tension PID/Parallel P Gain'
 * '<S21>'  : 'New_SPRO4/Tension PID/Reset Signal'
 * '<S22>'  : 'New_SPRO4/Tension PID/Saturation'
 * '<S23>'  : 'New_SPRO4/Tension PID/Saturation Fdbk'
 * '<S24>'  : 'New_SPRO4/Tension PID/Sum'
 * '<S25>'  : 'New_SPRO4/Tension PID/Sum Fdbk'
 * '<S26>'  : 'New_SPRO4/Tension PID/Tracking Mode'
 * '<S27>'  : 'New_SPRO4/Tension PID/Tracking Mode Sum'
 * '<S28>'  : 'New_SPRO4/Tension PID/Tsamp - Integral'
 * '<S29>'  : 'New_SPRO4/Tension PID/Tsamp - Ngain'
 * '<S30>'  : 'New_SPRO4/Tension PID/postSat Signal'
 * '<S31>'  : 'New_SPRO4/Tension PID/preInt Signal'
 * '<S32>'  : 'New_SPRO4/Tension PID/preSat Signal'
 * '<S33>'  : 'New_SPRO4/Tension PID/Anti-windup/Cont. Clamping Parallel'
 * '<S34>'  : 'New_SPRO4/Tension PID/Anti-windup/Cont. Clamping Parallel/Dead Zone'
 * '<S35>'  : 'New_SPRO4/Tension PID/Anti-windup/Cont. Clamping Parallel/Dead Zone/Enabled'
 * '<S36>'  : 'New_SPRO4/Tension PID/D Gain/Internal Parameters'
 * '<S37>'  : 'New_SPRO4/Tension PID/External Derivative/Error'
 * '<S38>'  : 'New_SPRO4/Tension PID/Filter/Cont. Filter'
 * '<S39>'  : 'New_SPRO4/Tension PID/Filter ICs/Internal IC - Filter'
 * '<S40>'  : 'New_SPRO4/Tension PID/I Gain/Internal Parameters'
 * '<S41>'  : 'New_SPRO4/Tension PID/Ideal P Gain/Passthrough'
 * '<S42>'  : 'New_SPRO4/Tension PID/Ideal P Gain Fdbk/Disabled'
 * '<S43>'  : 'New_SPRO4/Tension PID/Integrator/Continuous'
 * '<S44>'  : 'New_SPRO4/Tension PID/Integrator ICs/Internal IC'
 * '<S45>'  : 'New_SPRO4/Tension PID/N Copy/Disabled'
 * '<S46>'  : 'New_SPRO4/Tension PID/N Gain/Internal Parameters'
 * '<S47>'  : 'New_SPRO4/Tension PID/P Copy/Disabled'
 * '<S48>'  : 'New_SPRO4/Tension PID/Parallel P Gain/Internal Parameters'
 * '<S49>'  : 'New_SPRO4/Tension PID/Reset Signal/Disabled'
 * '<S50>'  : 'New_SPRO4/Tension PID/Saturation/Enabled'
 * '<S51>'  : 'New_SPRO4/Tension PID/Saturation Fdbk/Disabled'
 * '<S52>'  : 'New_SPRO4/Tension PID/Sum/Sum_PID'
 * '<S53>'  : 'New_SPRO4/Tension PID/Sum Fdbk/Disabled'
 * '<S54>'  : 'New_SPRO4/Tension PID/Tracking Mode/Disabled'
 * '<S55>'  : 'New_SPRO4/Tension PID/Tracking Mode Sum/Passthrough'
 * '<S56>'  : 'New_SPRO4/Tension PID/Tsamp - Integral/TsSignalSpecification'
 * '<S57>'  : 'New_SPRO4/Tension PID/Tsamp - Ngain/Passthrough'
 * '<S58>'  : 'New_SPRO4/Tension PID/postSat Signal/Forward_Path'
 * '<S59>'  : 'New_SPRO4/Tension PID/preInt Signal/Internal PreInt'
 * '<S60>'  : 'New_SPRO4/Tension PID/preSat Signal/Forward_Path'
 */
#endif                                 /* New_SPRO4_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
